---
name: 🤗 Support Question
about: If you have a question 💬 about configuring prompt.
---

<!--
If you have a trouble configuring `spaceship-prompt` on your machine, feel free to ask.
Make sure you're not asking duplicate question by searching on the issues lists.

Also read our TROUBLESHOOTING page for commonly encountered problems:

https://github.com/denysdovhan/spaceship-prompt/blob/master/docs/Troubleshooting.md
-->
